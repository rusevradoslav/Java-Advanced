package BankAccount;

public class BankAccount {
    final private static double DEFAULT_INTEREST_VALUE = 0.02;
    private static int accountCount = 1;
    private static double interestRate = DEFAULT_INTEREST_VALUE;
    private static int id;
    private static double balance;

    static void setInterestRate(double interestRate) {
        BankAccount.interestRate = interestRate;
    }

    public BankAccount() {
        this.id = accountCount++;
        balance = 0;
    }

    public static int getId() {
        return id;
    }

    public static void setId(int id) {
        BankAccount.id = id;
    }

    public static double getBalance() {
        return balance;
    }

    public static void setBalance(double balance) {
        BankAccount.balance = balance;
    }


    void deposit(double amount) {
        balance += amount;
    }

    double getInterest(int year) {
        return BankAccount.interestRate * year * this.balance;
    }
}
